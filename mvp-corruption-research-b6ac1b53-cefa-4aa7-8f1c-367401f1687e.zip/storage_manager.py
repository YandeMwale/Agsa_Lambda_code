# storage_manager.py

import boto3
import json
from datetime import datetime
import uuid
import os
from config import MVP_CONFIG

class S3StorageManager:
    def __init__(self):
        self.s3_client = boto3.client('s3')
        self.bucket_name = os.getenv('S3_BUCKET_NAME')
    
    def store_research(self, individual_name, results):
        """Store research results in S3 as line-delimited JSON"""
        try:
            research_id = str(uuid.uuid4())
            research_date = datetime.now().isoformat()
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_name = individual_name.replace(' ', '_').lower()
            
            # Create S3 key for LDJSON file
            s3_key = f"research/{safe_name}/{timestamp}_{safe_name}.json"

            # Build line-delimited JSON content (1 result per line)
            lines = []
            for result in results:
                flat_record = {
                    "research_id": research_id,
                    "individual_name": individual_name,
                    "research_date": research_date,
                    "version": "mvp-1.0",
                    "url": result.get("url"),
                    "title": result.get("title"),
                    "content": result.get("content"),
                    "score": result.get("score"),
                    "popi_act_compliant": True,
                    "research_purpose": "Corruption investigation",
                    "data_minimization_applied": True
                }
                lines.append(json.dumps(flat_record, ensure_ascii=False))  # no indent here!

            # Join all records into a single string (LDJSON)
            ldjson_data = '\n'.join(lines)

            # Upload to S3
            self.s3_client.put_object(
                Bucket=self.bucket_name,
                Key=s3_key,
                Body=ldjson_data.encode('utf-8'),
                ContentType='application/json',
                Metadata={
                    'individual-name': individual_name,
                    'research-type': 'corruption-investigation',
                    'country': 'South Africa'
                }
            )

            return s3_key

        except Exception as e:
            print(f"Storage error: {str(e)}")
            return None