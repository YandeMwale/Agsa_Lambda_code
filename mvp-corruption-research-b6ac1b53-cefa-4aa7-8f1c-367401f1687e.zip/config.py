# config.py
MVP_CONFIG = {
    "MAX_RESULTS": 20,
    "RETRY_ATTEMPTS": 3,
    "SA_SOURCES": [
        "news24.com", "timeslive.co.za", "mg.co.za", 
        "iol.co.za", "fin24.com", "dailymaverick.co.za"
    ]
}