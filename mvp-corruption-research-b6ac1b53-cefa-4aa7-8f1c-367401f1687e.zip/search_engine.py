# search_engine.py
from tavily import TavilyClient
from utils.error_handler import retry
from config import MVP_CONFIG
import random

class MVPSearchEngine:
    def __init__(self, api_key):
        self.tavily = TavilyClient(api_key=api_key)
        self.sa_sources = MVP_CONFIG["SA_SOURCES"]
    
    def build_search_query(self, individual_name):
        """Build SA-focused corruption search query using defined sources"""
        corruption_terms = [
            "corruption", "state capture", "bribery", "fraud",
            "embezzlement", "money laundering", "tender fraud",
            "kickback", "IDT", "Independent Developement trust" 
        ]

        # Use defined SA sources instead of generic ".za"
        selected_terms = random.sample(corruption_terms, k=random.randint(3, 4))
        corruption_query = " OR ".join(selected_terms)
        
        top_sources = random.sample(self.sa_sources, k=min(3, len(self.sa_sources)))
        sources_query = " OR ".join([f"site:{src}" for src in top_sources])
        query = (
            f'Extract adverse media about "{individual_name}" in South African news sources. '
            f'Make sure that you include full article text. '
            f'Remove all HTML tags and do not perform any summarisation. '
            f'Your role is to only extract text directly from the article and nothing more. '
            f'({corruption_query}) ({sources_query})'
        )
        return query
    
    @retry(max_attempts=MVP_CONFIG["RETRY_ATTEMPTS"], delay=2)
    def search_individual(self, individual_name, logger, max_results=MVP_CONFIG["MAX_RESULTS"]):
        """Main search function with error handling"""
        query = self.build_search_query(individual_name)
        
        try:
            response = self.tavily.search(
                query=query,
                search_depth="advanced",
                max_results=max_results,
                include_answer=True,
                include_raw_content=True
            )
            
            logger.info("Logging results: %d", len(response.get("results", [])))

            if not response or 'results' not in response:
                return []
            
            # Filter for relevant results
            relevant_results = self._filter_results(response['results'], individual_name)
            logger.info(f"Returning {len(relevant_results)} relevant results")  
            return relevant_results
            
        except Exception as e:
            raise Exception(f"Search failed: {str(e)}")
    
    def _filter_results(self, results, individual_name):
        """Filter results for relevance to individual and SA context"""
        filtered = []
        for result in results:
            content = f"{result.get('title', '')} {result.get('content', '')}".lower()
            if individual_name.lower() in content and any(
                keyword in content for keyword in ['corruption', 'bribery', 'fraud', 'scandal']
            ):
                filtered.append(result)
        return filtered