# main.py
import os
from search_engine import MVPSearchEngine
from storage_manager import S3StorageManager
from compliance_checker import POPIChecker
from utils.logger import setup_logger
from config import MVP_CONFIG
import json


def create_response(status_code, body):
    """Helper function to create properly formatted Lambda Function URL response"""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json'
        },
        'body': json.dumps(body) if isinstance(body, dict) else body
    }


def process_individual(individual_name, max_results, search_engine, storage_manager, compliance_checker, logger):
    """Helper function to process a single individual"""
    logger.info(f"Starting research on: {individual_name}")

    # Execute search
    results = search_engine.search_individual(individual_name, max_results)

    if not results:
        logger.warning(f"No results found for {individual_name}")
        return {"status": "success", "message": "No results found", "name": individual_name, "results": []}

    # Compliance check
    if not compliance_checker.validate_research(individual_name, results):
        logger.error(f"Compliance check failed for {individual_name}")
        return {"status": "error", "message": "Compliance check failed", "name": individual_name}

    # Store results
    s3_key = storage_manager.store_research(individual_name, results)

    if s3_key:
        logger.info(f"Research completed successfully for {individual_name}")
        s3_url = f"s3://{storage_manager.bucket_name}/{s3_key}"
        return {
            "status": "success",
            "message": f"Research completed for {individual_name}",
            "name": individual_name,
            "results_count": len(results),
            "s3_path": s3_url,
        }
    else:
        logger.error(f"Failed to store research results for {individual_name}")
        return {"status": "error", "message": "Storage failed", "name": individual_name}


def lambda_handler(event, context):
    logger = setup_logger()
    
    # Log remaining time for debugging
    logger.info(f"Lambda timeout: {context.get_remaining_time_in_millis()}ms")
    
    try:
       
        try:
            # Check for the 'body' key from API Gateway/Function URL
            if 'body' in event and isinstance(event['body'], str):
                request_body = json.loads(event['body'])
            else:
                # This handles direct test invocations from the AWS console
                request_body = event
        except json.JSONDecodeError:
            logger.error("Invalid JSON in request body")
            return create_response(400, {"status": "error", "message": "Invalid JSON in request body"})

        individual_name = request_body.get("name")
        names_list = request_body.get("names", [])
        max_results = request_body.get("max_results", MVP_CONFIG["MAX_RESULTS"])

        logger.info(f"Processing request for: {individual_name}, names_list: {names_list}")

        if not individual_name and not names_list:
            logger.error("Missing 'name' or 'names' in request payload")
            return create_response(400, {"status": "error", "message": "Missing 'name' or 'names' in request"})

        # Check if all required modules are available
        missing_modules = []
        if MVPSearchEngine is None:
            missing_modules.append("search_engine.MVPSearchEngine")
        if S3StorageManager is None:
            missing_modules.append("storage_manager.S3StorageManager")
        if POPIChecker is None:
            missing_modules.append("compliance_checker.POPIChecker")
            
        if missing_modules:
            error_msg = f"Missing required modules: {', '.join(missing_modules)}"
            logger.error(error_msg)
            return create_response(500, {"status": "error", "message": error_msg})

        if individual_name:
            names_list.append(individual_name)

        # Check remaining time before starting heavy operations
        remaining_time = context.get_remaining_time_in_millis()
        logger.info(f"Remaining time before processing: {remaining_time}ms")
        
        if remaining_time < 5000:  # Less than 5 seconds remaining
            logger.warning("Insufficient time remaining, returning early")
            return create_response(408, {"status": "error", "message": "Request timeout - insufficient time to process"})

        try:
            search_engine = MVPSearchEngine(os.getenv("TAVILY_API_KEY"))
            storage_manager = S3StorageManager()
            compliance_checker = POPIChecker()
            logger.info("Initialized all components successfully")
        except Exception as init_error:
            logger.error(f"Failed to initialize components: {str(init_error)}")
            return create_response(500, {"status": "error", "message": f"Initialization failed: {str(init_error)}"})

        results_summary = []
        for i, name in enumerate(names_list):
            # Check time remaining for each iteration
            remaining_time = context.get_remaining_time_in_millis()
            logger.info(f"Processing {name} ({i+1}/{len(names_list)}), remaining time: {remaining_time}ms")
            
            if remaining_time < 2000:  # Less than 2 seconds remaining
                logger.warning(f"Timeout approaching, processed {i} out of {len(names_list)} names")
                results_summary.append({
                    "status": "timeout", 
                    "message": f"Processing stopped due to timeout after {i} names", 
                    "name": name
                })
                break
                
            result = process_individual(name, max_results, search_engine, storage_manager, compliance_checker, logger)
            results_summary.append(result)

        response_body = {
            "status": "completed",
            "total_individuals": len(names_list),
            "processed": len(results_summary),
            "details": results_summary,
        }

        logger.info(f"Request completed successfully. Final remaining time: {context.get_remaining_time_in_millis()}ms")
        return create_response(200, response_body)

    except Exception as e:
        logger.error(f"Research failed: {str(e)}")
        return create_response(500, {"status": "error", "message": str(e)})