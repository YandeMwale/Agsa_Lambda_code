# main.py
import os
from search_engine import MVPSearchEngine
from storage_manager import S3StorageManager
from compliance_checker import POPIChecker
from utils.logger import setup_logger
from config import MVP_CONFIG


def process_individual(individual_name, max_results, search_engine, storage_manager, compliance_checker, logger):
    """Helper function to process a single individual"""
    logger.info(f"Starting research on: {individual_name}")

    # Execute search
    results = search_engine.search_individual(individual_name, logger, max_results)

    if not results:
        logger.warning(f"No results found for {individual_name}")
        return {"status": "success", "message": "No results found", "name": individual_name, "results": []}

    # Compliance check
    if not compliance_checker.validate_research(individual_name, results):
        logger.error(f"Compliance check failed for {individual_name}")
        return {"status": "error", "message": "Compliance check failed", "name": individual_name}

    # Store results
    success = storage_manager.store_research(individual_name, results)

    if success:
        logger.info(f"Research completed successfully for {individual_name}")
        return {
            "status": "success",
            "message": f"Research completed for {individual_name}",
            "name": individual_name,
            "results_count": len(results),
        }
    else:
        logger.error(f"Failed to store research results for {individual_name}")
        return {"status": "error", "message": "Storage failed", "name": individual_name}


def lambda_handler(event, context):
    """
    AWS Lambda handler for corruption research
    Accepts:
      - Single search: {"name": "Individual Name"}
      - Multiple search: {"names": ["Name1", "Name2", ...]}
    """
    logger = setup_logger()

    try:
        # Extract inputs
        individual_name = event.get("name")
        names_list = event.get("names", [])
        max_results = event.get("max_results", MVP_CONFIG["MAX_RESULTS"])

        if not individual_name and not names_list:
            return {"status": "error", "message": "Missing 'name' or 'names' in request"}

        # Normalize names to a list
        if individual_name:
            names_list.append(individual_name)

        # Initialize components once
        search_engine = MVPSearchEngine(os.getenv("TAVILY_API_KEY"))
        storage_manager = S3StorageManager()
        compliance_checker = POPIChecker()

        results_summary = []
        for name in names_list:
            result = process_individual(name, max_results, search_engine, storage_manager, compliance_checker, logger)
            results_summary.append(result)

        return {
            "status": "completed",
            "total_individuals": len(names_list),
            "details": results_summary,
        }

    except Exception as e:
        logger.error(f"Research failed: {str(e)}")
        return {"status": "error", "message": str(e)}