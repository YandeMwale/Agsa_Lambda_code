#error_handler.py
import time
import functools
import logging

logger = logging.getLogger("error-handler")

def retry(max_attempts=3, delay=2, allowed_exceptions=(Exception,)):
    """
    Retry decorator with exponential backoff.
    Useful for unstable external APIs (like Tavily).
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            attempt = 0
            while attempt < max_attempts:
                try:
                    return func(*args, **kwargs)
                except allowed_exceptions as e:
                    attempt += 1
                    wait = delay * attempt
                    logger.warning(
                        f"Attempt {attempt}/{max_attempts} failed for {func.__name__}: {e}. Retrying in {wait}s..."
                    )
                    time.sleep(wait)
            raise Exception(f"Function {func.__name__} failed after {max_attempts} attempts")

        return wrapper

    return decorator