#logger.py
import logging
import sys

def setup_logger(name="mvp-corruption-research"):
    """
    Setup structured JSON-like logging for Lambda (stdout).
    AWS Lambda automatically captures logs sent to stdout.
    """
    logger = logging.getLogger(name)

    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            fmt="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)

    return logger