#compliance_checker.py
"""
Basic POPI Act compliance checker for corruption research MVP
"""

class POPIChecker:
    def __init__(self):

        # List of prohibited sensitive data categories
        self.prohibited_terms = [
            "medical", "religion", "sexual", "minor",
            "race", "ethnic", "biometric"
        ]

    def validate_research(self, individual_name: str, results: list) -> bool:
        """
        Validates results based on basic POPIA principles:
        - Avoids special personal information
        - Keeps processing limited and relevant
        - Assumes all data is publicly sourced

        Returns:
            bool (or dict if return_details is True)
        """
        if not results:
            return False

        # Very basic filtering: check if sensitive categories are in results
        for result in results:
            combined = f"{result.get('title', '')} {result.get('content', '')} {result.get('url', '')}".lower()
            if any(term in combined for term in self.prohibited_terms):
                return False

        return True